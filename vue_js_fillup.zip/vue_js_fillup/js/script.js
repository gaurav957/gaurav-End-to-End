Vue.component('header_panel', {
	  props: ['user'],
	template:'<div v-html="user.userdetails.name">Hello</div>'
});

var vueObj = new Vue({
	el:'#wrapper',
	data:{
		alldata:{},
		userdetailsdata:{},
		
	},
	created:function(){
		console.log($("#tdtdata").length);
		if($("#tdtdata").length){
			this.alldata = JSON.parse($('#tdtdata').text().trim());
			this.userdetailsdata = this.alldata.userdetails;
			console.log(this.userdetailsdata);
		}
	}
	
});