  $( function() {
	  
	  var _totalSliders = totalSliders;
	  var _initialValue = initialValue;
	  var _minimumValue = minimumValue;
	  var _maximumValue = maximumValue;
	  
	  (function createSliders(){
		  for(var i=1;i<=_totalSliders;i++){
			  
			  $(".slider-wrapper").append("<div class='slider-range-min' id=slider"+i+"></div>");
			  $(".output").append("<input id=output"+i+"></input>")
		  }
	  })();
	  
	$(".slider-range-min").each(function(){
		
    $(this).slider({
		
      range: "min",
      value: 0,
      min: _minimumValue,
      max: _maximumValue,
		
		create:function(event,ui){
			var curValue = ui.value || _initialValue;
		  	var tooltip = "<span id='tooltip'>" + curValue + "</span>";
			$(this).find("span").html(tooltip);
		},
      slide:function(event,ui) {
		  var curValue = ui.value || _initialValue;
		  var tooltip = "<span id='tooltip'>" + curValue + "</span>";
		  //console.log($(this));
		$(this).find("span").html(tooltip);
		  //console.log("ui.vale"+ui.value);
		 //console.log($(this).find("span").attr("id","tooltip").text(ui.value));
		  //$("#tooltip").text(  ui.value  );
		  //console.log($(this).attr("id").split("slider")[1]);
		  var getSliderId = $(this).attr("id").split("slider")[1];
		  //console.log( "#output"+a );
		  $( "#output"+getSliderId ).val(ui.value );
		  
	  }
     
    });
		}) ;
	  
  });